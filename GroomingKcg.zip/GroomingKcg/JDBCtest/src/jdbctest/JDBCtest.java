package jdbctest;

public class JDBCtest {

    public static void main(String[] args) {
        Connector koneksi = new Connector();
        ViewInput v = new ViewInput();
        v.setVisible(true);
        v.setLocationRelativeTo(null);
    }
    
}
